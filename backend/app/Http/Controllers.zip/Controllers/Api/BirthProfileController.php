<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\BirthProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class BirthProfileController extends Controller
{
    /**
     * Display logged in user's birth profile.
     */
    public function plist()
    {
        $profile = BirthProfile::with('latestHoroscope')
		->where('user_id', Auth::id())
		->get()
		->map(function ($profile){
			return [
				'id' => $profile->id,
				'full_name' => $profile->full_name,
				'relation' => $profile->relation,
				'date_of_birth' => $profile->date_of_birth,
				'has_horoscope' => $profile->latestHoroscope !== null,
				'horoscope_id' => optional($profile->latestHoroscope)->id,
			];
		});

        return response()->json([
            'status' => true,
            'data' => $profile
        ]);
    }
	
	public function show($id)
    {
        $profile = BirthProfile::select('id','full_name','relation','gender','date_of_birth','time_of_birth','place_of_birth')->where('user_id', Auth::id())->where('id',$id)->first();

        return response()->json([
            'status' => true,
            'data' => $profile
        ]);
    }

    /**
     * Store Birth Profile.
     */
    public function store(Request $request)
    {
        
        $validator=Validator::make($request->all(),[

			'full_name'=>'required|string|max:255',

			'gender'=>'required|in:male,female,prefer_not_to_say',

			'relation'=>'required|string|max:50',

			'date_of_birth'=>'required|date',

			'birth_time_known'=>'required|boolean',

			'time_of_birth'=>'nullable',

			'country'=>'required|string|max:100',

			'state'=>'nullable|string|max:100',

			'city'=>'required|string|max:100',

			]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

		$place=$request->city;

		if($request->state){

			$place.=', '.$request->state;

		}

		$place.=', '.$request->country;

		$profile=BirthProfile::create([

		'user_id'=>Auth::id(),

		'full_name'=>$request->full_name,

		'gender'=>$request->gender,

		'relation'=>$request->relation,

		'date_of_birth'=>$request->date_of_birth,

		'birth_time_known'=>$request->birth_time_known,

		'time_of_birth'=>$request->birth_time_known
		?$request->time_of_birth
		:null,

		'country'=>$request->country,

		'state'=>$request->state,

		'city'=>$request->city,

		'place_of_birth'=>$place,

		'latitude'=>null,

		'longitude'=>null,

		'timezone'=>null

		]);

        return response()->json([
            'status' => true,
            'message' => 'Birth profile created successfully.',
            'data' => $profile
        ], 201);
    }

    /**
     * Update Birth Profile.
     */
    public function update(Request $request)
    {
        $profile = BirthProfile::where('user_id', Auth::id())->first();

        if (!$profile) {
            return response()->json([
                'status' => false,
                'message' => 'Birth profile not found.'
            ], 404);
        }

        $validator=Validator::make($request->all(),[

			'full_name'=>'required|string|max:255',

			'gender'=>'required|in:male,female,prefer_not_to_say',

			'relation'=>'required|string|max:50',

			'date_of_birth'=>'required|date',

			'birth_time_known'=>'required|boolean',

			'time_of_birth'=>'nullable',

			'country'=>'required|string|max:100',

			'state'=>'nullable|string|max:100',

			'city'=>'required|string|max:100',

			]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $profile->update($request->only([
            'full_name',
            'gender',
			'relation',
            'date_of_birth',
            'time_of_birth',
            'place_of_birth',
            'latitude',
            'longitude',
            'timezone'
        ]));

        return response()->json([
            'status' => true,
            'message' => 'Birth profile updated successfully.',
            'data' => $profile
        ]);
    }
}